Recipes
=======

Here you'll find recipes to help get your Brisket apps started. Got your own recipe? Submit a pull request.

* [Fetching Multiple Models](fetching-multiple-models.md)
* [Bundling with Browserify](bundling-with-browserify.md)
* [Jump To Top Of Page On New Route](jump-to-top-of-page-on-new-route.md)
* [Tracking Page View](tracking-page-view.md)
* [Handling Errors in a Route](handling-errors-in-a-route-handler.md)

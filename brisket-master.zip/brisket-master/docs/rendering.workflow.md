Rendering Workflow
==================

When you call `render` on a Brisket.View (including Brisket.Layouts), there is a rendering workflow with allows Brisket.Views to be environment agnostic. This section will cover what happens during that workflow in detail.
